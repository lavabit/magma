#ifndef _CHECK_CHECK_STDINT_H
#define _CHECK_CHECK_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "check 0.11.0"
/* generated using gnu compiler Apple LLVM version 7.3.0 (clang-703.0.31) */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
