#define RARVER_MAJOR     5
#define RARVER_MINOR    90
#define RARVER_BETA      0
#define RARVER_DAY      26
#define RARVER_MONTH     3
#define RARVER_YEAR   2020
