#ifdef _WIN32

#ifndef WIN32_CONFIG
#define WIN32_CONFIG


#define STDC_HEADERS

#define snprintf _snprintf
#define vsnprintf _vsnprintf 


#endif

#endif
