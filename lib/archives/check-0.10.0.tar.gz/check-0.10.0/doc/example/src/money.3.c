#include <stdlib.h>
#include "money.h"

Money *money_create(int amount, char *currency)
{
    return NULL;
}

int money_amount(Money * m)
{
    return 0;
}

char *money_currency(Money * m)
{
    return NULL;
}

void money_free(Money * m)
{
    return;
}
